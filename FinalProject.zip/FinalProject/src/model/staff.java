package model;

import java.util.ArrayList;

import entity.staffentity;

public class staff {
    private static ArrayList<staffentity> staffList = new ArrayList<>();

    public static void iniData() {
        staffentity staff1 = new staffentity("Ardian", "Ardian", "07394");
        staffentity staff2 = new staffentity("Safira", "Safira", "12345");
        staffList.add(staff1);
        staffList.add(staff2);
    }

    public static staffentity findUsername(String username) {
        for (staffentity staffentity : staffList) {
            if (staffentity.getUsername().equals(username)) {
                return staffentity;
            }
        }
        return null;
    }

}