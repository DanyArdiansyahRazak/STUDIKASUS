package model;

import java.util.ArrayList;

import entity.bukuentity;

public class buku {
    private static ArrayList<bukuentity> bukuList = new ArrayList<>();

    public static void iniData() {
        bukuentity buku1 = new bukuentity("1","Air Ketuban", "Dany", "1", "2022");

        bukuentity buku2 = new bukuentity("2","Gangguan Rahim", "Razak", "2", "2022");

        bukuList.add(buku1);
        bukuList.add(buku2);
    }

    public static ArrayList<bukuentity> all() {

        return bukuList;
    }

    public static bukuentity findkode(String kode) {
        for (bukuentity bukuentity : bukuList) {
            if (bukuentity.getkode().equals(kode)) {
                return bukuentity;
            }
        }

        return null;
    }

    public static void insert(bukuentity bukuBaru) {
        bukuList.add(bukuBaru);
    }

    public static void update(bukuentity bukuEdited) {
        int index = indexData(bukuEdited.getkode());

        if (index != -1) {
            bukuList.set(index, bukuEdited);
        }
    }

    public static void remove(String kode) {
        int index = indexData(kode);

        if (index != -1) {
            bukuList.remove(index);
        }
    }

    public static int indexData(String kode) {
        bukuentity bukuFind = findkode(kode);
        return bukuList.indexOf(bukuFind);
    }
}
