package controller;

import view.admin.dashboard;

public class dashboardcontroller {

    public void toView() {
        dashboard dashboardpage = new dashboard();

    }
}
