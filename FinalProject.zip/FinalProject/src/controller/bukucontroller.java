package controller;

import entity.bukuentity;
import model.buku;

public class bukucontroller {

    public boolean tambahData(String no, String judul, String pengarang, String kode, String tahun) {

        // Cek apakah kode sudah terdaftar atau belum
        if (buku.findkode(kode) == null) {
            // Jika belum terdaftar maka lanjutkan proses INSERT

            // Buat Object Entitas
            bukuentity bukuBaru = new bukuentity(no, judul, pengarang, kode, tahun);

            // Kirim ke Model
            buku.insert(bukuBaru);

            return true;
        }

        return false;
    }

    public bukuentity cariData(String kode) {
        return buku.findkode(kode);
    }

    public boolean updateData(String no, String judul, String pengarang, String kodeLama, String tahun) {

        // Buat Object Entitas
        bukuentity bukubaru = new bukuentity(no, judul, pengarang, kodeLama, tahun);

        // Kirim ke Model
        buku.update(bukubaru);

        return true;
    }

    public void removeData(String kode) {
        buku.remove(kode);
    }

}

