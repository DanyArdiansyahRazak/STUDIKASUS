package controller;

import java.util.ArrayList;
import entity.bukuentity;

import entity.staffentity;
import model.staff;
import view.login;
        

public class logincontroller {
    public void toView() {
        login loginpage = new login();
    }
    public boolean loginProccess(String username, String password) {
        staffentity staffentity = staff.findUsername(username);
        // Cek apakah ada ada data dengan Username yang dikirim pada Parameter ?
        if (staffentity != null) {
            // Jika ada cek Password nya
            if (staffentity.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
}

