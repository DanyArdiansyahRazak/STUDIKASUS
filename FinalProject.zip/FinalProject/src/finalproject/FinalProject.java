package finalproject;

import java.util.*;
import java.awt.*;
import view.*;

public class FinalProject {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }
    
}
