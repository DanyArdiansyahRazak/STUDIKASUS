package entity;

public class bukuentity extends entity {
     private String no, nama, pengarang, kode, tahun;

    public bukuentity(String no, String nama, String pengarang, String kode, String tahun) {
        super (nama);
        this.no = kode;
        this.pengarang = pengarang;
        this.kode = kode;
        this.tahun =  tahun;
    }

    public String getjudul() {
        return nama;
    }

    public String getpengarang() {
        return pengarang;
    }

    public String getkode() {
        return kode;
    }
    
    public String gettahun(){
        return tahun;
    }

    public void setjudul(String judul) {
        this.nama = judul;
    }

    public void setpengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public void setkode(String kode) {
        this.kode = kode;
    }
    
    public void settahun(String tahun) {
        this.tahun = tahun;
    }
}
