package entity;

public class entity {
   protected String Nama; //modifier protected

    public entity(String Nama) {
        this.Nama = Nama;
    }
    
    /**
     * funtion-function dibawah ini merupakan 
     * function getter dan setter (accessor) 
     * yang digunakan untuk mengakses 
     * variable yang terenkapsulasi 
     * (dalam kasus ini protected)
    */
    
    public String getNama() {
        return Nama;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    } 
}
