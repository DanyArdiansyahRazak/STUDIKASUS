package view.buku;

import java.util.Scanner;
import controller.bukucontroller;
import entity.bukuentity;
import view.admin.dashboard;

public class edit {
    private Scanner input = new Scanner(System.in);
    private bukucontroller _bukuC = new bukucontroller();
    

    public void editData(String kode) {
        // Bawa Ke Controller untuk mengecek data berdasarkan kode
        bukuentity bukuCari = _bukuC.cariData(kode);
        if (bukuCari != null) {
            inputData(bukuCari);
        } else {
            System.out.println("Kode " + kode + " Tidak Ditemukan !");
        }
    }

    private void inputData(bukuentity bukuCari) {
        String judul;
        String pengarang;
        String tahun;
        String no = bukuCari.getkode();
        System.out.print("Masukan judul      : ");
        judul = input.nextLine();

        System.out.println();

        System.out.print("Masukan Pengarang   : ");
        pengarang = input.nextLine();

        System.out.println();

        System.out.print("Masukan Tahun   : ");
        tahun = input.nextLine();
        
        boolean status = _bukuC.updateData(bukuCari.getkode(),no , judul, pengarang, tahun);

        if (status) {
            System.out.println("BERHASIL MENGUBAH DATA");
        }

    }
}
