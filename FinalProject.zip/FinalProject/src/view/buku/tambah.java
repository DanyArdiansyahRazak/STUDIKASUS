package view.buku;

import java.util.Scanner;

import controller.bukucontroller;

public class tambah {
    private Scanner input = new Scanner(System.in);
    private bukucontroller _bukuC = new bukucontroller();

    public void inputData() {
        String no, judul, pengarang, kode, tahun;

        System.out.println("\n--------- TAMBAH DATA BUKU ----------");

        System.out.print("Masukan Judul    : ");
        judul = input.nextLine();

        System.out.print("Masukan pengarang : ");
        pengarang = input.nextLine();
        
        System.out.print("Masukan kode     : ");
        kode = input.nextLine();
        no = kode;
        
        System.out.print("Masukan tahun : ");
        tahun = input.nextLine();

        boolean status = _bukuC.tambahData(no, judul, pengarang, kode, tahun);

        if (status) {
            System.out.println("BERHASIL MENAMBAHKAN DATA");
        } else {
            System.out.println("GAGAL MENAMBAHKAN DATA");
            System.out.println("Kode " + kode + " Sudah terdaftar!");
        }

    }

}
