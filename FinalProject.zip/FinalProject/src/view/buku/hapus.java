package view.buku;

import java.util.Scanner;
import controller.bukucontroller;
import entity.bukuentity;

public class hapus {
    private Scanner input = new Scanner(System.in);
    private bukucontroller _bukuC = new bukucontroller();

    public void hapusData() {
        String kode;

        System.out.println("\n---------- HAPUS DATA BUKU ----------");

        System.out.print("Masukan kode yang ingin dihapus : ");
        kode = input.nextLine();

        // Bawa Ke Controller untuk mengecek data berdasarkan kode
        bukuentity bukuCari = _bukuC.cariData(kode);
        if (bukuCari != null) {
            _bukuC.removeData(kode);
            System.out.println("BERHASIL MENGHAPUS DATA");

        } else {
            System.out.println("kode " + kode + " Tidak Ditemukan !");
            
        }
    }

}

